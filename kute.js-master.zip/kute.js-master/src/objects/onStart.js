// schedule property specific function on animation start
// link property update function to KUTE.js execution context
const onStart = {};
export default onStart;
