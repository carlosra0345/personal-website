// link properties to interpolate functions
const linkProperty = {};
export default linkProperty;
