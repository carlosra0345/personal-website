// used in preparePropertiesObject
const prepareProperty = {};
export default prepareProperty;
