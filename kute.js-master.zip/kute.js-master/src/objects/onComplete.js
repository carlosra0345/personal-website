// schedule property specific function on animation complete
const onComplete = {};
export default onComplete;
