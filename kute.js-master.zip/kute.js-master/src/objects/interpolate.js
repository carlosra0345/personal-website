// KUTE.js INTERPOLATE FUNCTIONS
// =============================
const interpolate = {};
export default interpolate;
