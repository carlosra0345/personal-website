// check current property value when .to() method is used
const prepareStart = {};
export default prepareStart;
