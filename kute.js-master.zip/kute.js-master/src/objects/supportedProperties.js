// all supported properties
const supportedProperties = {};
export default supportedProperties;
