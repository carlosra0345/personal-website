/**
 * The KUTE.js Execution Context
 */
const KEC = {};
export default KEC;
