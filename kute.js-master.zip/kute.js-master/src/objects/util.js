// util - a general object for utils like rgbToHex, processEasing
const Util = {};
export default Util;
