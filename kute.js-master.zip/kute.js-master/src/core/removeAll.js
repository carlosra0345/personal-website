import Tweens from '../objects/tweens';

/**
 * KUTE.removeAll()
 */
const removeAll = () => { Tweens.length = 0; };

export default removeAll;
