// @ts-ignore
import { version } from '../../package.json';

/**
 * A global namespace for library version.
 * @type {string}
 */
const Version = version;
export default Version;
