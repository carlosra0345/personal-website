// IE10+
import 'minifill/src/Array.from';
import 'minifill/src/Array.prototype.flat';
import 'minifill/src/Array.prototype.includes';
import 'minifill/src/String.prototype.includes';
import 'minifill/src/Number.isFinite';
import 'minifill/src/Number.isInteger';
import 'minifill/src/Number.isNaN';
