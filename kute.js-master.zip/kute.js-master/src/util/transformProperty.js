import trueProperty from './trueProperty';

/** the `transform` string for legacy browsers */
const transformProperty = trueProperty('transform');
export default transformProperty;
